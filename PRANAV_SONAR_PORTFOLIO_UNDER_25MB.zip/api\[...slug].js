/**
 * Vercel Serverless Function Catch-All Router (...slug)
 * Matches any /api/x/y call on Vercel and forwards it to server.js
 */
const handleRequest = require('../server.js');

module.exports = (req, res) => {
  try {
    if (req.query && req.query.slug) {
      const slugParts = Array.isArray(req.query.slug) ? req.query.slug : [req.query.slug];
      const search = req.url && req.url.includes('?') ? req.url.slice(req.url.indexOf('?')) : '';
      req.url = '/api/' + slugParts.join('/') + search;
    } else if (req.headers && req.headers['x-matched-path']) {
      req.url = req.headers['x-matched-path'];
    }
    return handleRequest(req, res);
  } catch (err) {
    console.error('[API CATCH-ALL ERROR]:', err);
    if (!res.headersSent) {
      res.writeHead(500, { 'Content-Type': 'application/json; charset=utf-8', 'Access-Control-Allow-Origin': '*' });
      res.end(JSON.stringify({ success: false, error: 'Internal Serverless Handler Error', message: err.message }));
    }
  }
};

