// Vercel Serverless Function Entrypoint
// Dispatches incoming serverless requests to the core application handler in server.js
const handleRequest = require('../server.js');

module.exports = (req, res) => {
  try {
    if (req.query && req.query.slug) {
      const slugParts = Array.isArray(req.query.slug) ? req.query.slug : [req.query.slug];
      const search = req.url && req.url.includes('?') ? req.url.slice(req.url.indexOf('?')) : '';
      req.url = '/api/' + slugParts.join('/') + search;
    } else if (req.headers && req.headers['x-forwarded-uri']) {
      req.url = req.headers['x-forwarded-uri'];
    } else if (req.headers && req.headers['x-matched-path'] && !req.headers['x-matched-path'].includes('/api/index')) {
      req.url = req.headers['x-matched-path'];
    }
    return handleRequest(req, res);
  } catch (err) {
    console.error('[API INDEX ERROR]:', err);
    if (!res.headersSent) {
      res.writeHead(500, { 'Content-Type': 'application/json; charset=utf-8', 'Access-Control-Allow-Origin': '*' });
      res.end(JSON.stringify({ success: false, error: 'Internal Serverless Handler Error', message: err.message }));
    }
  }
};

